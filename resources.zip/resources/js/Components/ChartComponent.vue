<script lang="ts">



</script>

<template>
    <h2>ChartJS</h2>
    <canvas id="myChart"> </canvas>
</template>
